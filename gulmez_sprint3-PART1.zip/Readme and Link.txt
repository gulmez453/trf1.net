I've included a free gift order form. Retrieves information and gives a summary of the order on the new page.

jQuery, jQuery UI widgets and functions used in the form listed below.

I used a data collector in the form that can be ordered in the future.
I used jquery to change the number when pressing + and -.
I also used a jQuery that changes the gift types in dropdownmenu by clicking on the text.
I added a jquery that collects the form information and displays it on the new page. I also wrote two functions that map and print two arrays.
In addition, mail and name and address control are also provided.

The Github link is as follows.
https://gulmez453.github.io/trf1.net/gift.html